var odcinek_8cpp =
[
    [ "operator<<", "odcinek_8cpp.html#a6d8457c5a8044e1bf65f18f77aaa04f9", null ],
    [ "operator>>", "odcinek_8cpp.html#a283e5377496fea37695e562fd5987f4a", null ]
];