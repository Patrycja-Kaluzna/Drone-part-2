var annotated_dup =
[
    [ "PzG", "namespace_pz_g.html", "namespace_pz_g" ],
    [ "Dron", "class_dron.html", "class_dron" ],
    [ "Odcinek", "class_odcinek.html", "class_odcinek" ],
    [ "Powierzchnia", "class_powierzchnia.html", null ],
    [ "Powierzchnia_dna", "class_powierzchnia__dna.html", "class_powierzchnia__dna" ],
    [ "Powierzchnia_wody", "class_powierzchnia__wody.html", "class_powierzchnia__wody" ],
    [ "Prostopadloscian", "class_prostopadloscian.html", null ],
    [ "Scena", "class_scena.html", "class_scena" ],
    [ "SMacierz", "class_s_macierz.html", "class_s_macierz" ],
    [ "SWektor", "class_s_wektor.html", "class_s_wektor" ],
    [ "Wieloscian", "class_wieloscian.html", "class_wieloscian" ]
];