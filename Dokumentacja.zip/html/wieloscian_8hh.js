var wieloscian_8hh =
[
    [ "Wieloscian", "class_wieloscian.html", "class_wieloscian" ],
    [ "Macierz3x3", "wieloscian_8hh.html#aed1284f591ec1baca78f5efe8fb1b783", null ]
];