var class_dron =
[
    [ "Dron", "class_dron.html#ae9b8a464e28bef5d688f49f7d9443fed", null ],
    [ "czy_kolizja", "class_dron.html#a540146fdd9983a073bf3aea29a76da06", null ],
    [ "ruch_na_wprost", "class_dron.html#aa74553b240c50054e91b5ac31e4b1d42", null ],
    [ "zmiana_orientacji", "class_dron.html#a588412b0dab31b8440a94f3d02d35ee6", null ],
    [ "zwroc_max_x", "class_dron.html#ac1b0c6e66fd9e9aff651c1008582b513", null ],
    [ "zwroc_max_y", "class_dron.html#a077a35ae4dee4f1ce0055183e741cc49", null ],
    [ "zwroc_max_z", "class_dron.html#a7f0e021880db4bd1b4bca696d3c21f57", null ],
    [ "zwroc_min_x", "class_dron.html#af7413521dba2e91da754f58038e5196d", null ],
    [ "zwroc_min_y", "class_dron.html#aa5da5ef7b284b65e18c715d314efbb46", null ],
    [ "zwroc_min_z", "class_dron.html#aa11d33a7cd1c6b6b263b0bacc3214ac2", null ],
    [ "_Kadlub", "class_dron.html#a23b6ab8ca776d3113990bb2b410b90d7", null ],
    [ "_Sruba1", "class_dron.html#a0b264af6f83f02f0c11cac4d6e5a34c7", null ],
    [ "_Sruba2", "class_dron.html#a964d3e5637ec6b5641ba7b91277d3636", null ]
];