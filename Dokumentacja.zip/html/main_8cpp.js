var main_8cpp =
[
    [ "main", "main_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ],
    [ "wyswietl_ilosc_Wektorow3D", "main_8cpp.html#a5c647eee2cfeb15feda209e9d9dc0c26", null ],
    [ "wyswietl_menu", "main_8cpp.html#a4c4d61fabfebcaa5ba706952073e4b28", null ]
];