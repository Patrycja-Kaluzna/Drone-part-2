var files =
[
    [ "dron.cpp", "dron_8cpp.html", null ],
    [ "dron.hh", "dron_8hh.html", [
      [ "Dron", "class_dron.html", "class_dron" ]
    ] ],
    [ "lacze_do_gnuplota.cpp", "lacze__do__gnuplota_8cpp.html", "lacze__do__gnuplota_8cpp" ],
    [ "lacze_do_gnuplota.hh", "lacze__do__gnuplota_8hh.html", "lacze__do__gnuplota_8hh" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "odcinek.cpp", "odcinek_8cpp.html", "odcinek_8cpp" ],
    [ "odcinek.hh", "odcinek_8hh.html", "odcinek_8hh" ],
    [ "powierzchnia.cpp", "powierzchnia_8cpp.html", null ],
    [ "powierzchnia.hh", "powierzchnia_8hh.html", [
      [ "Powierzchnia", "class_powierzchnia.html", null ]
    ] ],
    [ "powierzchnia_dna.cpp", "powierzchnia__dna_8cpp.html", null ],
    [ "powierzchnia_dna.hh", "powierzchnia__dna_8hh.html", [
      [ "Powierzchnia_dna", "class_powierzchnia__dna.html", "class_powierzchnia__dna" ]
    ] ],
    [ "powierzchnia_wody.cpp", "powierzchnia__wody_8cpp.html", null ],
    [ "powierzchnia_wody.hh", "powierzchnia__wody_8hh.html", [
      [ "Powierzchnia_wody", "class_powierzchnia__wody.html", "class_powierzchnia__wody" ]
    ] ],
    [ "prostopadloscian.cpp", "prostopadloscian_8cpp.html", null ],
    [ "prostopadloscian.hh", "prostopadloscian_8hh.html", [
      [ "Prostopadloscian", "class_prostopadloscian.html", null ]
    ] ],
    [ "scena.cpp", "scena_8cpp.html", null ],
    [ "scena.hh", "scena_8hh.html", [
      [ "Scena", "class_scena.html", "class_scena" ]
    ] ],
    [ "SMacierz.hh", "_s_macierz_8hh.html", "_s_macierz_8hh" ],
    [ "SWektor.hh", "_s_wektor_8hh.html", "_s_wektor_8hh" ],
    [ "wieloscian.cpp", "wieloscian_8cpp.html", null ],
    [ "wieloscian.hh", "wieloscian_8hh.html", "wieloscian_8hh" ]
];