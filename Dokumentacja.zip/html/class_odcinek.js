var class_odcinek =
[
    [ "get_Punkty_lokalne", "class_odcinek.html#aea1ce85fad6afd2e4bceb04f2ca69945", null ],
    [ "set_Punkty_lokalne", "class_odcinek.html#a8d55a52336ba8c48d08bcdf14476ff0b", null ],
    [ "zwroc_max_x", "class_odcinek.html#a6485adac7cab95dc2fabdd663c136ea8", null ],
    [ "zwroc_max_y", "class_odcinek.html#acf94795fa1a8223fed261305b33cfab2", null ],
    [ "zwroc_max_z", "class_odcinek.html#ad56dd10a430d0046b5e64a15935fd42b", null ],
    [ "zwroc_min_x", "class_odcinek.html#aa76f07245b6f8038916691eae6ccc0af", null ],
    [ "zwroc_min_y", "class_odcinek.html#ae0987cf06e2a1ac2c4665a46764c984b", null ],
    [ "zwroc_min_z", "class_odcinek.html#ae6dc10ca1e2bbba5bd0cc08f700690e7", null ],
    [ "zwroc_wskaznik_do_globalnych", "class_odcinek.html#a496334e5abe2fa6db515d08a6c7d0212", null ],
    [ "zwroc_wskaznik_do_lokalnych", "class_odcinek.html#a5fbd5ea8f116d8f17bd72227f7522de4", null ],
    [ "_Punkty_globalne", "class_odcinek.html#a119191f2968743b51669f81651b24fa2", null ],
    [ "_Punkty_lokalne", "class_odcinek.html#a27403271cc59c0ec49c63baff23f43ee", null ]
];