var lacze__do__gnuplota_8hh =
[
    [ "InfoPlikuDoRysowania", "class_pz_g_1_1_info_pliku_do_rysowania.html", "class_pz_g_1_1_info_pliku_do_rysowania" ],
    [ "LaczeDoGNUPlota", "class_pz_g_1_1_lacze_do_g_n_u_plota.html", "class_pz_g_1_1_lacze_do_g_n_u_plota" ],
    [ "RodzajRysowania", "lacze__do__gnuplota_8hh.html#a705c92106f39b7d0c34a6739d10ff0b6", [
      [ "RR_Ciagly", "lacze__do__gnuplota_8hh.html#a705c92106f39b7d0c34a6739d10ff0b6a927eaa159aa4bd3198f0a330b967746d", null ],
      [ "RR_Punktowy", "lacze__do__gnuplota_8hh.html#a705c92106f39b7d0c34a6739d10ff0b6aa01097ee8266d6402b752ef6f9a4690c", null ]
    ] ],
    [ "TrybRysowania", "lacze__do__gnuplota_8hh.html#aeedae1ef10c66d720f9e89de408ca4ca", [
      [ "TR_2D", "lacze__do__gnuplota_8hh.html#aeedae1ef10c66d720f9e89de408ca4caa5eb0cf8b3405e136f092efdb489d60c4", null ],
      [ "TR_3D", "lacze__do__gnuplota_8hh.html#aeedae1ef10c66d720f9e89de408ca4caa856e6b0fa6b8a9dc184c60cf27dcc5d2", null ]
    ] ]
];