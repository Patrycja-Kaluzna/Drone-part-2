var class_powierzchnia__dna =
[
    [ "Powierzchnia_dna", "class_powierzchnia__dna.html#aa64ff4e10a26f2a91c3fc8f9b4635207", null ]
];