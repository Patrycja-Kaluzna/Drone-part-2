var class_wieloscian =
[
    [ "Wieloscian", "class_wieloscian.html#a83f521e38107bca76540281f8673abd1", null ],
    [ "get_Punkty_globalne", "class_wieloscian.html#a597832d6f84c855f936e5a58e6a6af4a", null ],
    [ "liczba_Punktow_globalnych", "class_wieloscian.html#a2af0888f431da835b833d03cd503fc1b", null ],
    [ "oblicz_Macierz_rotacji", "class_wieloscian.html#adc46fcc054488c79266f61dde682d1f3", null ],
    [ "oblicz_Wektor_przemieszczenia", "class_wieloscian.html#a5339784b7fdc4094d0c234f53dddf852", null ],
    [ "ruch_na_wprost", "class_wieloscian.html#a50dcd63e785dd4bd25aa8109ae63da96", null ],
    [ "set_Punkty_globalne", "class_wieloscian.html#a7269b44fe3272e3a329d9d92db60f025", null ],
    [ "ustaw_Kat_orientacji", "class_wieloscian.html#a9a492cab68e32a24e9f13422a5c7f557", null ],
    [ "ustaw_Macierz_rotacji", "class_wieloscian.html#a05d324cf1697843425308eb09cc8f1de", null ],
    [ "ustaw_Wektor_translacji", "class_wieloscian.html#a46be60b224798deb49ad518c4b6eda61", null ],
    [ "wczytaj_globalne", "class_wieloscian.html#a6c1f194ca0c880f92712526c7b935052", null ],
    [ "zmiana_orientacji", "class_wieloscian.html#a380cb665fbef97b296463639cc8584e3", null ],
    [ "_Kat_orientacjiX", "class_wieloscian.html#a87bb3415ef71c7ec8d93bb342c0ac2f0", null ],
    [ "_Kat_orientacjiY", "class_wieloscian.html#a8ccc28b5608c29ec339afb6159651734", null ],
    [ "_Kat_orientacjiZ", "class_wieloscian.html#a3ca36890779697f9c09ba703d654edbf", null ],
    [ "_Macierz_rotacji", "class_wieloscian.html#a836f435604288553a438c43728df736e", null ],
    [ "_ostatnia_zmiana_orientacji", "class_wieloscian.html#a7eb011f0f3ce41d824d98260b97507f7", null ],
    [ "_Wektor_translacji", "class_wieloscian.html#a28a19502d733d4ea63b127f876a1a51d", null ]
];