var _s_wektor_8hh =
[
    [ "SWektor", "class_s_wektor.html", "class_s_wektor" ],
    [ "operator<<", "_s_wektor_8hh.html#a46199701884bc67ef3e0f67fda5d0712", null ],
    [ "operator>>", "_s_wektor_8hh.html#a91b2f2d06128a4754329234cac63fead", null ]
];