#ifndef ODCINEK_HH
#define ODCINEK_HH

#include "SWektor.hh"
#include <fstream>
#include <vector>

typedef SWektor<double, 3> Wektor3D;

class Odcinek {

protected:

std::vector<Wektor3D> _Punkty_lokalne;

std::vector<Wektor3D> _Punkty_globalne;

public:

std::vector<Wektor3D>::const_iterator get_Punkty_lokalne () const;

std::vector<Wektor3D>::iterator set_Punkty_lokalne ();

/*!
 * \brief Pozwala na dostęp do kontenera zawierającego
 * zbiór punktów w lokalnym układzie odniesienia.
 */
std::vector<Wektor3D> * zwroc_wskaznik_do_lokalnych ();

std::vector<Wektor3D> * zwroc_wskaznik_do_globalnych ();

double zwroc_max_x ();

double zwroc_min_x ();

double zwroc_max_y ();

double zwroc_min_y ();

double zwroc_max_z ();

double zwroc_min_z ();

};

/*!
 * \brief Wczytuje ze strumienia plikowego zbiór punktów
 *  w lokalnym układzie odniesienia.
 */ 
std::ifstream & operator >> (std::ifstream & Fstr, Odcinek & Pow);

std::ofstream & operator << (std::ofstream & Fstr, Odcinek & Odc);

#endif