#ifndef WIELOSCIAN_HH
#define WIELOSCIAN_HH

#include "powierzchnia.hh"
#include "SMacierz.hh"
#include <cmath>

typedef SMacierz <double, 3> Macierz3x3;
                         
class Wieloscian: public Powierzchnia {

public: //Pola powinny być protected, ale wtedy źle się rysuje:/

double _Kat_orientacjiX;

double _Kat_orientacjiY;

double _Kat_orientacjiZ;

Macierz3x3 _Macierz_rotacji;

Wektor3D _Wektor_translacji;

char _ostatnia_zmiana_orientacji;

Wieloscian ();
/*
Wektor3D get_Wektor_translacji () const {
    return _Wektor_translacji;}

Wektor3D & set_Wektor_translacji () {
    return _Wektor_translacji;}

Macierz3x3 get_Macierz_rotacji () const {
    return _Macierz_rotacji;}
*/
/*!
 * \brief Wczytuje zbiór punktów w globalnym układzie odniesienia.
 */
void wczytaj_globalne ();

/*!
 * \brief Umożliwia dostęp do kontenera z punktami globalnymi.
 */
std::vector<Wektor3D>::const_iterator get_Punkty_globalne () const;

std::vector<Wektor3D>::iterator set_Punkty_globalne ();

/*!
 * \brief Ustawia wartość pola _Kat_orientacji odpowiednio X, Y lub Z.
 */
void ustaw_Kat_orientacji (double kat, char wymiar);

void ustaw_Macierz_rotacji (char wymiar);

Macierz3x3 oblicz_Macierz_rotacji (char wymiar) const;

void ustaw_Wektor_translacji (double odleglosc);

/*!
 * \brief Oblicza wektor przemieszczenia.
 */
Wektor3D oblicz_Wektor_przemieszczenia (double odleglosc) const;   

/*!
 * \brief Porusza prostopadłościan na wprost.
 */
void ruch_na_wprost (double odleglosc);

/*!
 * \brief Obraca prostopadłościan wokół osi Z.
 */
void zmiana_orientacji (double kat, char wymiar);

/*!
 * \brief Zwraca liczbę elementów kontenera z puntkami globalnymi.
 */
unsigned int liczba_Punktow_globalnych () const;

};

#endif