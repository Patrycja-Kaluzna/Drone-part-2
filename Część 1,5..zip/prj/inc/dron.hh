#ifndef DRON_HH
#define DRON_HH

/*!
 * \file
 * \brief Definicja klasy Dron
 * Plik zawiera definicję klasy Dron.
 */

#include "prostopadloscian.hh"
#include <fstream>
#include <memory>

/*!
 * \brief Modeluje pojęcie drona,
 * którego cechą jest jego kadłub
 * będący prostopadłościanem oraz
 * śruby będące wielościanami.
 */

class Dron {
    
public: //Pola powinny być protected, ale wtedy źle się rysuje:/

Prostopadloscian _Kadlub;

Wieloscian _Sruba1;

Wieloscian _Sruba2;

Dron ();

/*
Prostopadloscian get_Kadlub () const {
    return _Kadlub;}

Wieloscian get_Sruba1 () const {
    return _Sruba1;}

Wieloscian get_Sruba2 () const {
    return _Sruba2;}

Wektor3D get_Wektor_translacji () const {
    return _Kadlub.get_Wektor_translacji();}

Macierz3x3 get_Macierz_rotacji() const {
    return _Kadlub.get_Macierz_rotacji();}
*/

void ruch_na_wprost (double odleglosc);

//Wektor3D oblicz_srodek_kadluba (char uklad) const;

//Wektor3D oblicz_srodek_sruby (int numer_sruby) const;

void zmiana_orientacji (double kat, char wymiar);

double zwroc_max_x ();

double zwroc_min_x ();

double zwroc_max_y ();

double zwroc_min_y ();

double zwroc_max_z ();

double zwroc_min_z ();

bool czy_kolizja (std::vector<std::shared_ptr<Odcinek>> zbior_przeszkod);

};

#endif